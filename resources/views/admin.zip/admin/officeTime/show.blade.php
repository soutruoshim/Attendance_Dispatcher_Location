<div class="modal fade" id="addslider" tabindex="-1" aria-labelledby="addslider" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
            </div>
            <div class="modal-body">
                <strong>Opening Time:</strong> <p class="opening_time"> </p> <br>

                <strong>Closing Time:</strong> <p class="closing_time"> </p><br>

                <strong>Shift:</strong> <p class="shift"> </p><br>

                <strong>Description:</strong> <p class="description"> </p>

            </div>
        </div>
    </div>
</div>
