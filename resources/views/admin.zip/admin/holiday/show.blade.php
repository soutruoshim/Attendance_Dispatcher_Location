
<div class="modal fade" id="addslider" tabindex="-1" aria-labelledby="addslider" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
            </div>
            <div class="modal-body">
                <strong>Event:</strong> <p class="occasion"> </p> <br>

                <strong>Event Date:</strong> <p class="occasion_date"> </p><br>

                <strong>Description:</strong> <p class="note"> </p>

            </div>
        </div>
    </div>
</div>
