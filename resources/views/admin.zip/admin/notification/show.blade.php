<div class="modal fade" id="addslider" tabindex="-1" aria-labelledby="addslider" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
            </div>
            <div class="modal-body">
                <div class="col-lg-12 mb-3">
                    <b>Notified Member</b> : <p class="form-control"  id="notifiedUser" ></p><br>

                    <textarea class="form-control"  name="description" id="description" rows="10"></textarea>

                </div>

            </div>
        </div>
    </div>
</div>


