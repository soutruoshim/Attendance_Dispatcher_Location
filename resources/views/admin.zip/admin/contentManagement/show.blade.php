<div class="modal fade" id="addslider" tabindex="-1" aria-labelledby="addslider" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
            </div>
            <div class="modal-body">
                <div class="col-lg-12">
                    <p class="form-control" id="description" style="height: 300px; overflow-y: scroll"></p>
                </div>
            </div>
        </div>
    </div>
</div>


